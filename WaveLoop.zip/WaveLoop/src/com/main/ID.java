package com.main;

public enum ID {

	Player(),
	Trail(),
	BasicEnemy(),
	HardEnemy(),
	SmartEnemy(),
	EnemyBoss(),
	MenuParticle(),
	Coin(),
	FastEnemy();
	
	
}
